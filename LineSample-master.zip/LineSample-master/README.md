# LINE SAMPLE

Unity Line draw sample without using LineRenderer.
It creates polygon and draws line.

![art](./art/smile.png)
